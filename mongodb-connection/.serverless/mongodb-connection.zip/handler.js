//'use strict';

var mongoose = require("mongoose");
var encryption = require("./pureFunctions/encryption");
var models = require("./db/models");
var auth = require("./pureFunctions/auth");

var dbURI = "mongodb://testuser:testuser@ds041536.mlab.com:41536/inztest";
//var dbURI = 'mongodb://localhost/mydatabase';

mongoose.connect(dbURI);
mongoose.connection.on('connected', function () {//connected
    console.log("Mongoose is connected");
    // process.exit(1);
});

/////////////////////////////////////////////////////////////////////////////////////
module.exports.signup = (event, context, cb) => {

    console.log("query: ", event.query);
    console.log("body: ", event.body);

    var username = event.body.username;
    var password = event.body.password;

    encryption.stringToHash(password).then(function (passwordHash) {

        console.log("abc");
        var newUser = new models.user({
            username: username,
            password: passwordHash
        });
        newUser.save(function (err, data) {
            if (err) {
                console.log("error: ", err);
            } else {
                console.log("data: ", data);
            }
            cb(null, {
                message: 'Signup Success!',
                event
            });
        });
    }, function (error) {
        cb("bcrypt error", { message: 'Signup Success!', error });
    });
}

/////////////////////////////////////////////////////////////////////////////////////
module.exports.login = (event, context, cb) => {

    console.log("body: ", event.body);
    var username = event.body.username;
    var password = event.body.password;

    models.user.findOne({ username: "zeeshan" }, function (err, data) {
        if (err) {

            console.log("some error occured in findOne: ", err);
            cb(null, {
                message: 'some error occured in findOne!',
                event
            });

        } else {

            
            console.log(" user found in database generating token... data: ",data);
            //generate token here and send to user
            auth.generateToken({ username: data.username }).then(function (token) {

                console.log("logged in successfully, token: ", token);
                cb(null, {
                    message: 'logged in successfully, token: ' + token,
                    event
                });

            }, function (err) {
                console.log("error in token generation: ", err);
                cb(null, {
                    message: 'error in token generation',
                    event
                });
            });
        }
    })

};

/////////////////////////////////////////////////////////////////////////////////////////
module.exports.profile = (event, context, cb) => {
    //verify token here

};
/////////////////////////////////////////////////////////////////////////////////////
